window.Locales = window.Locales || {};

window.Locales['tr'] = {
    loadingText: "Yükleniyor...",
    
    musicDefaultTitle: "Müzik Yükleniyor...",
    musicDefaultArtist: "Lütfen Bekleyin",
    
    gameCenterTitle: "OYUN MERKEZİ",
    gameBackBtn: "Menüye Dön",
    
    game2048: "2048 Puzzle",
    gameDino: "Dino Run"
};