window.Locales = window.Locales || {};

window.Locales['en'] = {
    loadingText: "LOADING SERVER DATA",
    musicDefaultTitle: "Waiting for Music...",
    musicDefaultArtist: "Please Wait",
    
    gameCenterTitle: "Mini Games",
    gameBackBtn: "Go Back",
    
    game2048Title: "2048",
    game2048Desc: "Join the numbers and get to the 2048 tile!",
    
    gameDinoTitle: "Dino Run",
    gameDinoDesc: "Jump over obstacles and get the highest score!"
};