fx_version 'cerulean'
game 'gta5'

author 'Eros Scripts'
description 'Eros Loading'
version '1.0.0'

lua54 'yes'

loadscreen 'index.html'

files {
    'index.html',
    'style.css',
    'config.js',
    'script.js',
    'locales/*.js',
    'assets/server-logo.png',
    'assets/backgrounds/*.jpg',
    'assets/backgrounds/*.mp4',
    'assets/backgrounds/*.webm',
    'assets/music/*.mp3',
    'assets/music/*.jpg'
}

server_script 'server.lua'