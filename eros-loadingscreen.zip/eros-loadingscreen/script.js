window.addEventListener('DOMContentLoaded', () => {
    if (typeof Config === 'undefined') { console.error("Config Yok!"); return; }
    applySettings(); initBackgrounds(); loadSong(currentSong);
    let p = audio.play(); if(p !== undefined) p.then(_=> { isPlaying = true; updatePlayIcon(); }).catch(e=>{});
    document.body.addEventListener('click', () => { if(!isPlaying) playTrack(); }, { once: true });
});

function applySettings() {
    document.documentElement.style.setProperty('--eros-color', Config.themeColor);
    const langKey = Config.language;
    if(window.Locales && window.Locales[langKey]) {
        const lang = window.Locales[langKey];
        setText('loading-text', lang.loadingText);
        setText('track-title', lang.musicDefaultTitle);
        setText('track-artist', lang.musicDefaultArtist);
        setText('game-center-title', lang.gameCenterTitle);
        setText('btn-back-menu', lang.gameBackBtn);
        setText('txt-game-2048-title', lang.game2048Title);
        setText('txt-game-2048-desc', lang.game2048Desc);
        setText('txt-game-dino-title', lang.gameDinoTitle);
        setText('txt-game-dino-desc', lang.gameDinoDesc);
    }
    const vSlider = document.getElementById('volume-slider');
    if(vSlider) vSlider.value = Config.defaultVolume;
    audio.volume = Config.defaultVolume / 100;
}
function setText(id, txt) { const el = document.getElementById(id); if(el) el.innerText = txt; }

function initBackgrounds() {
    const bgSlider = document.getElementById('bg-slider');
    const localVideo = document.getElementById('bg-video-local');
    const youtubeContainer = document.getElementById('bg-video-youtube');
    bgSlider.style.display = 'none'; localVideo.style.display = 'none'; youtubeContainer.style.display = 'none';

    if (Config.backgroundType === 'image') {
        bgSlider.style.display = 'block';
        Config.backgrounds.forEach((bg, i) => {
            const div = document.createElement('div');
            div.classList.add('bg-slide'); div.style.backgroundImage = `url('assets/backgrounds/${bg}')`;
            if (i === 0) div.classList.add('active'); bgSlider.appendChild(div);
        });
        let bgIndex = 0;
        setInterval(() => { const slides = document.querySelectorAll('.bg-slide'); if(slides.length > 1) { slides[bgIndex].classList.remove('active'); bgIndex = (bgIndex + 1) % slides.length; slides[bgIndex].classList.add('active'); } }, Config.backgroundSettings.slideInterval);
    } else if (Config.backgroundType === 'video-local') {
        localVideo.style.display = 'block'; localVideo.src = `assets/backgrounds/${Config.backgroundSettings.localVideoFile}`; localVideo.muted = Config.backgroundSettings.muted; localVideo.play().catch(e => {});
    } else if (Config.backgroundType === 'youtube') {
        youtubeContainer.style.display = 'block'; const vidId = Config.backgroundSettings.youtubeVideoId; const isMuted = Config.backgroundSettings.muted ? '1' : '0';
        youtubeContainer.innerHTML = `<iframe src="https://www.youtube.com/embed/${vidId}?enablejsapi=1&autoplay=1&controls=0&fs=0&iv_load_policy=3&showinfo=0&rel=0&loop=1&playlist=${vidId}&mute=${isMuted}" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>`;
    }
}

const audio = new Audio();
const playBtn = document.getElementById('play-btn'); const cover = document.getElementById('music-cover'); const title = document.getElementById('track-title'); const artist = document.getElementById('track-artist');
const seekSlider = document.getElementById('seek-slider'); const volumeSlider = document.getElementById('volume-slider'); const currTime = document.getElementById('curr-time'); const totalTime = document.getElementById('total-duration');
const musicPlayerUI = document.getElementById('music-player'); const uiContainer = document.querySelector('.ui-content');
let currentSong = 0; let isPlaying = false; let updateTimer;

document.getElementById('game-btn').addEventListener('click', () => { document.getElementById('game-overlay').classList.add('active'); showGameMenu(); musicPlayerUI.classList.remove('show'); });
document.getElementById('close-game-btn').addEventListener('click', () => { document.getElementById('game-overlay').classList.remove('active'); setTimeout(() => { document.getElementById('game-frame').src = ""; }, 300); });
document.getElementById('music-btn').addEventListener('click', () => { musicPlayerUI.classList.toggle('show'); });
document.getElementById('eye-btn').addEventListener('click', function() { uiContainer.classList.toggle('ui-hidden'); let icon = this.querySelector('i'); if (uiContainer.classList.contains('ui-hidden')) icon.classList.replace('fa-eye-slash', 'fa-eye'); else icon.classList.replace('fa-eye', 'fa-eye-slash'); });

(function() {
    const dot = document.getElementById('cursor-dot'); const ring = document.getElementById('cursor-ring');
    let mouseX = 0, mouseY = 0, ringX = 0, ringY = 0;
    document.addEventListener('mousemove', (e) => { mouseX = e.clientX; mouseY = e.clientY; });
    function animateCursor() { dot.style.left = mouseX + 'px'; dot.style.top = mouseY + 'px'; ringX += (mouseX - ringX) * 0.15; ringY += (mouseY - ringY) * 0.15; ring.style.left = ringX + 'px'; ring.style.top = ringY + 'px'; requestAnimationFrame(animateCursor); } animateCursor();
    const interactiveSelectors = 'button, input, a, .game-card, .icon-btn, input[type="range"]';
    document.addEventListener('mouseover', (e) => { if (e.target.matches(interactiveSelectors) || e.target.closest(interactiveSelectors)) { dot.classList.add('hovered'); ring.classList.add('hovered'); } else { dot.classList.remove('hovered'); ring.classList.remove('hovered'); } });
    document.addEventListener('mousedown', () => { ring.classList.add('clicking'); dot.style.transform = "translate(-50%, -50%) scale(0.5)"; });
    document.addEventListener('mouseup', () => { ring.classList.remove('clicking'); dot.style.transform = "translate(-50%, -50%) scale(1)"; });
    document.addEventListener('mouseout', (e) => { if (!e.relatedTarget && !e.toElement) { dot.style.opacity = '0'; ring.style.opacity = '0'; } });
    document.addEventListener('mouseover', () => { dot.style.opacity = '1'; ring.style.opacity = '0.6'; });
})();

document.addEventListener('mousemove', (e) => {
    if(uiContainer.classList.contains('ui-hidden')) return;
    const x = (e.clientX - window.innerWidth / 2); const y = -(e.clientY - window.innerHeight / 2);
    uiContainer.style.transform = `rotateX(${y / 120}deg) rotateY(${x / 120}deg)`;
    const reflection = document.getElementById('reflection');
    if(reflection) reflection.style.backgroundPosition = `${50 + (x / window.innerWidth * 15)}% ${50 + (-y / window.innerHeight * 15)}%`;
});

function loadSong(index) {
    clearInterval(updateTimer); resetValues(); if(!Config.playlist || Config.playlist.length === 0) return;
    const song = Config.playlist[index]; audio.src = `assets/music/${song.file}`; audio.load(); cover.src = `assets/music/${song.cover}`; 
    title.innerText = song.title; artist.innerText = song.artist;
    updateTimer = setInterval(seekUpdate, 1000); audio.addEventListener('ended', nextSong);
}
function resetValues() { currTime.innerText = "0:00"; totalTime.innerText = "0:00"; seekSlider.value = 0; }
function updatePlayIcon() { if (isPlaying) { playBtn.classList.replace('fa-play', 'fa-pause'); playBtn.style.marginLeft = "0px"; } else { playBtn.classList.replace('fa-pause', 'fa-play'); playBtn.style.marginLeft = "2px"; } }
function playTrack() { audio.play(); isPlaying = true; updatePlayIcon(); }
function pauseTrack() { audio.pause(); isPlaying = false; updatePlayIcon(); }
function playPause() { if(isPlaying) pauseTrack(); else playTrack(); }
function nextSong() { currentSong = (currentSong + 1) % Config.playlist.length; loadSong(currentSong); playTrack(); }
function prevSong() { currentSong = (currentSong - 1 + Config.playlist.length) % Config.playlist.length; loadSong(currentSong); playTrack(); }
function seekTo() { let seekto = audio.duration * (seekSlider.value / 100); audio.currentTime = seekto; }
function setVolume() { audio.volume = volumeSlider.value / 100; }
function seekUpdate() { if (!isNaN(audio.duration)) { let sk = audio.currentTime * (100 / audio.duration); seekSlider.value = sk; let cm = Math.floor(audio.currentTime / 60); let cs = Math.floor(audio.currentTime - cm * 60); let dm = Math.floor(audio.duration / 60); let ds = Math.floor(audio.duration - dm * 60); if (cs < 10) cs = "0" + cs; if (ds < 10) ds = "0" + ds; currTime.innerText = cm + ":" + cs; totalTime.innerText = dm + ":" + ds; } }

playBtn.parentElement.addEventListener('click', playPause); document.getElementById('next-btn').addEventListener('click', nextSong); document.getElementById('prev-btn').addEventListener('click', prevSong);
seekSlider.addEventListener('change', seekTo); seekSlider.addEventListener('input', seekTo); volumeSlider.addEventListener('input', setVolume);
window.openGame = function(gameKey) { document.getElementById('game-menu-view').style.display = 'none'; document.getElementById('game-play-view').style.display = 'flex'; const lang = (window.Locales && window.Locales[Config.language]) || {}; let gameName = "Game"; if (gameKey === '2048') gameName = lang.game2048 || "2048"; if (gameKey === 'dino') gameName = lang.gameDino || "Dino"; document.getElementById('current-game-name').innerText = gameName; document.getElementById('game-frame').src = Config.games[gameKey]; }
window.showGameMenu = function() { document.getElementById('game-play-view').style.display = 'none'; document.getElementById('game-menu-view').style.display = 'flex'; document.getElementById('game-frame').src = ""; }
window.addEventListener('message', (e) => { if (e.data.eventName === 'loadProgress') { const val = parseInt(e.data.loadFraction * 100); document.getElementById('progress-bar').style.width = val + '%'; document.getElementById('percentage-text').innerText = (val >= 100 ? '%100' : '%' + val); } });