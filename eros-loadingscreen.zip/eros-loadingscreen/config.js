const Config = {
    language: 'en',
    themeColor: '#a8a8a8',
    
    // TR- video-local (assets/background içine at background.mp4 olarak.) , youtube (linki yapıştır) , image (varsayılan)
    // EN-video-local (put background.mp4 in assets/background), youtube (paste link), image (default)
    backgroundType: 'image',

    backgroundSettings: {
        slideInterval: 5000,
        localVideoFile: 'background.mp4',
        youtubeVideoId: 'dQw4w9WgXcQ',
        muted: true
    },

    backgrounds: [
        "bg1.jpg",
        "bg2.jpg",
        "bg3.jpg"
    ],

    defaultVolume: 30,
    playlist: [
        { file: "m1.mp3", cover: "k1.jpg", title: "Rodman Dennis", artist: "UZI x Motive" },
        { file: "m2.mp3", cover: "k2.jpg", title: "Trap House", artist: "UZI x Motive" }
    ],

    games: {
        '2048': 'https://elgoog.im/2048/',
        'dino': 'https://chromedino.com/'
    }
};